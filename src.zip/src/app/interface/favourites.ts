export interface Favourites {
  id:number,
  userId: any,
  title: string,
  poster_path: string
}
