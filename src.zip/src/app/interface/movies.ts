export interface Movies {
    id:number,
    title: string,
    poster_path: string
}
